<?php
class mailsmsTemplates extends Eloquent {
	public $timestamps = false;
	protected $table = 'mailsmsTemplates';
}