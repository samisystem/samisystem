<?php
class bookLibrary extends Eloquent {
	public $timestamps = false;
	protected $table = 'bookLibrary';
}