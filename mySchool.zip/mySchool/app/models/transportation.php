<?php
class transportation extends Eloquent {
	public $timestamps = false;
	protected $table = 'transportation';
}