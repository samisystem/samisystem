<?php
class attendance extends Eloquent {
	public $timestamps = false;
	protected $table = 'attendance';
}