<?php
class examsList extends Eloquent {
	public $timestamps = false;
	protected $table = 'examsList';
}