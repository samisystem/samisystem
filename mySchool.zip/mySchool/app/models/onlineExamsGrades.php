<?php
class onlineExamsGrades extends Eloquent {
	public $timestamps = false;
	protected $table = 'onlineExamsGrades';
}